package pizzeria;

//strategia
//interfejs w ktorym, deklarujemy funklcje
public interface CenaDowozu {
    public int ileDowoz(int cena);
}
